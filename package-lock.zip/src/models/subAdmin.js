const mongoose = require('mongoose')


const subAdmin = new mongoose.Schema({
    
})