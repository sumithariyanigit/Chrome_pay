module.exports = {
    'facebookAuth': {
        'clientID': '1467410000407007',
        'clientSecret': '6bab3beec74f17e8c86f4200c70432d4',
        'callbackURL': 'http://localhost:3000/api/v1/user/return'
    }
}